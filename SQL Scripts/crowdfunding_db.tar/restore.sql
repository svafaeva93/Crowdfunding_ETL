--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 15.2
-- Dumped by pg_dump version 15.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE crowdfunding_db;
--
-- Name: crowdfunding_db; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE crowdfunding_db WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'C';


ALTER DATABASE crowdfunding_db OWNER TO postgres;

\connect crowdfunding_db

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Campaign; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Campaign" (
    cf_id integer NOT NULL,
    contact_id integer NOT NULL,
    company_name character varying(255) NOT NULL,
    description character varying(255) NOT NULL,
    goal double precision NOT NULL,
    pledged double precision NOT NULL,
    outcome character varying(255) NOT NULL,
    backers_count integer NOT NULL,
    country character varying(255) NOT NULL,
    currency character varying(255) NOT NULL,
    launched_date date NOT NULL,
    end_date date NOT NULL,
    category_id character varying(255) NOT NULL,
    subcategory_id character varying(255) NOT NULL
);


ALTER TABLE public."Campaign" OWNER TO postgres;

--
-- Name: Category; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Category" (
    category_id character varying(255) NOT NULL,
    category character varying(255) NOT NULL
);


ALTER TABLE public."Category" OWNER TO postgres;

--
-- Name: Contacts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Contacts" (
    contact_id integer NOT NULL,
    first_name character varying(255) NOT NULL,
    last_name character varying(255) NOT NULL,
    email character varying(255) NOT NULL
);


ALTER TABLE public."Contacts" OWNER TO postgres;

--
-- Name: Subcategory; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Subcategory" (
    subcategory_id character varying(255) NOT NULL,
    subcategory character varying(255) NOT NULL
);


ALTER TABLE public."Subcategory" OWNER TO postgres;

--
-- Data for Name: Campaign; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Campaign" (cf_id, contact_id, company_name, description, goal, pledged, outcome, backers_count, country, currency, launched_date, end_date, category_id, subcategory_id) FROM stdin;
\.
COPY public."Campaign" (cf_id, contact_id, company_name, description, goal, pledged, outcome, backers_count, country, currency, launched_date, end_date, category_id, subcategory_id) FROM '$$PATH$$/3606.dat';

--
-- Data for Name: Category; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Category" (category_id, category) FROM stdin;
\.
COPY public."Category" (category_id, category) FROM '$$PATH$$/3604.dat';

--
-- Data for Name: Contacts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Contacts" (contact_id, first_name, last_name, email) FROM stdin;
\.
COPY public."Contacts" (contact_id, first_name, last_name, email) FROM '$$PATH$$/3603.dat';

--
-- Data for Name: Subcategory; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Subcategory" (subcategory_id, subcategory) FROM stdin;
\.
COPY public."Subcategory" (subcategory_id, subcategory) FROM '$$PATH$$/3605.dat';

--
-- Name: Campaign pk_Campaign; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Campaign"
    ADD CONSTRAINT "pk_Campaign" PRIMARY KEY (cf_id);


--
-- Name: Category pk_Category; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Category"
    ADD CONSTRAINT "pk_Category" PRIMARY KEY (category_id);


--
-- Name: Contacts pk_Contacts; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Contacts"
    ADD CONSTRAINT "pk_Contacts" PRIMARY KEY (contact_id);


--
-- Name: Subcategory pk_Subcategory; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Subcategory"
    ADD CONSTRAINT "pk_Subcategory" PRIMARY KEY (subcategory_id);


--
-- Name: Campaign fk_Campaign_category_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Campaign"
    ADD CONSTRAINT "fk_Campaign_category_id" FOREIGN KEY (category_id) REFERENCES public."Category"(category_id);


--
-- Name: Campaign fk_Campaign_contact_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Campaign"
    ADD CONSTRAINT "fk_Campaign_contact_id" FOREIGN KEY (contact_id) REFERENCES public."Contacts"(contact_id);


--
-- Name: Campaign fk_Campaign_subcategory_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Campaign"
    ADD CONSTRAINT "fk_Campaign_subcategory_id" FOREIGN KEY (subcategory_id) REFERENCES public."Subcategory"(subcategory_id);


--
-- PostgreSQL database dump complete
--

